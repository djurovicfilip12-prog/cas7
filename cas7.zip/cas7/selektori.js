let name = prompt("Please enter yout name");
let color = prompt("What is your favourite color sir");

let onename = document.getElementById("onename");

onename.innerText = name;
onename.style.color = color;
