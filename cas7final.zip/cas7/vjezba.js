let name = prompt("Hi there, can you please enter your name");
console.log(name);

let nameWeb = document.getElementById("nameWeb");

nameWeb.innerText = name;
nameWeb.style.color = "blue";





