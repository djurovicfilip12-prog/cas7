// Get Element by ID

let name = prompt("Enter Your Name below");
console.log(name);

let color = prompt("WhaT text color would you like?");
console.log(color);

let backcolor = prompt("What background color would you like");

let marqueeElement = document.getElementById("name");
marqueeElement.style.color = color;
marqueeElement.style.backgroundColor = backcolor;
marqueeElement.innerText = name;


/**
 * -getElementById
 * - getElementByClassName
 * -querySelector 
 * -querySelectorAll - 
 * 
 */



