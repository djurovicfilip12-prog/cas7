
let ads = [

    {
        title: "Porsche Taycan",
        price: 100000,
        image:"https://www.bing.com/images/search?view=detailV2&ccid=fzWceQkp&id=1064F23AF917872A00CC3F8C8C3D0AF1B10D08F5&thid=OIP.fzWceQkpd9ZUUoCxrrH1LAHaE8&mediaurl=https%3a%2f%2fstatic0.carbuzzimages.com%2fwordpress%2fwp-content%2fuploads%2fgallery-images%2foriginal%2f1227000%2f600%2f1227675.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.7f359c79092977d6545280b1aeb1f52c%3frik%3d9QgNsfEKPYyMPw%26pid%3dImgRaw%26r%3d0&exph=2000&expw=3000&q=porsche+taycan&FORM=IRPRST&ck=1D57C529BACBF29F70988966670844F8&selectedIndex=8&itb=0",
    },

    {
        title: "Porsche Macan",
        price: 100000,
        image: "https://www.bing.com/images/search?view=detailV2&ccid=UlWpZn1h&id=2EDE402BDED39FCF90B1587F4BA08AE02D02D72E&thid=OIP.UlWpZn1hLUq0rXixWLZLmwHaFj&mediaurl=https%3a%2f%2fs1.cdn.autoevolution.com%2fimages%2fgallery%2fPORSCHE-Macan-S-Diesel-5539_12.jpg&cdnurl=https%3a%2f%2fth.bing.com%2fth%2fid%2fR.5255a9667d612d4ab4ad78b158b64b9b%3frik%3dLtcCLeCKoEt%252fWA%26pid%3dImgRaw%26r%3d0&exph=1536&expw=2048&q=porsche+macan&FORM=IRPRST&ck=16AFBD961DD50ACE2AC2AF66D1456CF2&selectedIndex=7&itb=0",
    },

    {
        title: "Porsche Carrera",
        price: 100000,
        image:"https://images-porsche.imgix.net/-/media/FD402231FB8E484F9B0B2932814F55A6_D9B1EC9FA94E450BA1CB16961F6C5F95_CZ26W03OX0005-911-carrera-s-rear?w=1720&h=1232&q=85&crop=faces%2Centropy%2Cedges&auto=format"
    }
]



let productsElement = document.getElementById("products")

for (let ad in ads){
productsElement.innerText+=ads[ad]["title"]+ " " + ads[ad]["price"]+ " "+  ads[ad]["image"];
}



